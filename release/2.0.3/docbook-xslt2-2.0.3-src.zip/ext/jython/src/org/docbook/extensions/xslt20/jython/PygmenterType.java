package org.docbook.extensions.xslt20.jython;

public interface PygmenterType {
    public String format(String code, String language);
}
